/* @ds-bundle: {"format":3,"namespace":"DesignSystemSISHIS_52dd83","components":[],"sourceHashes":{"panels-ext.js":"d2f62c383c21"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DesignSystemSISHIS_52dd83 = window.DesignSystemSISHIS_52dd83 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// panels-ext.js
try { (() => {
// panels-ext.js – Tab implementations cho các module còn stub
// Yêu cầu: helpers (kpiCard, chartCard, tableCard, div, mkChart, IC) từ Dashboard HIS.html

// ── SHARED DATA ──
const KHOA = ['Tim Mạch', 'Ngoại TH', 'Nhi Khoa', 'Sản Khoa', 'Thần Kinh', 'Nội Tiết', 'Ung Bướu', 'Chỉnh Hình', 'Phổi', 'Tiêu Hóa'];
const BS = ['BS. Nguyễn Văn A', 'BS. Trần Thị B', 'BS. Lê Văn C', 'BS. Phạm Thị D', 'BS. Hoàng Văn E', 'BS. Đỗ Thị F', 'BS. Vũ Văn G', 'BS. Bùi Thị H', 'BS. Đinh Văn I', 'BS. Ngô Thị K'];
const PKH = ['PK Nội TH', 'PK Tim Mạch', 'PK Nhi', 'PK Sản', 'PK Thần Kinh', 'PK Nội Tiết', 'PK Ung Bướu', 'PK Mắt', 'PK Tai Mũi Họng', 'PK Da Liễu'];
Object.assign(PANELS, {
  // ══════════ NGOẠI TRÚ ══════════

  // Tab 2 – Theo Phòng Khám
  'ngoaitru-1': () => {
    const f = document.createDocumentFragment();
    const rows = PKH.map((p, i) => {
      const bn = [82, 67, 54, 48, 39, 35, 28, 42, 38, 31][i];
      const tkm = [18, 22, 20, 25, 28, 24, 30, 15, 22, 18][i];
      const tch = [22, 28, 25, 18, 32, 20, 24, 12, 18, 15][i];
      return `<tr><td><strong>${p}</strong></td><td>${bn}</td><td>${tkm} phút</td><td ${tch > 25 ? 'style="color:var(--red);font-weight:600;"' : ''}>${tch} phút</td></tr>`;
    }).join('');
    f.appendChild(div('', tableCard('2.1 &nbsp;Hiệu Suất Từng Phòng Khám', 'Tổng BN, thời gian khám & chờ trung bình trong kỳ', ['Phòng Khám', 'Tổng BN', 'TG Khám TB (phút)', 'TG Chờ TB (phút)'], rows, 'Xem tất cả')));
    const r = div('', '');
    r.innerHTML = chartCard('2.2 &nbsp;BN Theo Đối Tượng Từng Phòng', 'Phân cơ cấu đối tượng thanh toán theo phòng khám', 'barStackPK', `<div class="legend" style="margin-top:8px;">${[['#1d63c4', 'BHYT'], ['#c0552f', 'Dịch Vụ'], ['#15803d', 'BHTN'], ['#a4a4a0', 'Miễn Phí']].map(([c, n]) => `<div class="li"><div class="ld" style="background:${c};"></div>${n}</div>`).join('')}</div>`);
    f.appendChild(r);
    return f;
  },
  // Tab 3 – Theo Bác Sĩ
  'ngoaitru-2': () => {
    const f = document.createDocumentFragment();
    const rows = BS.map((b, i) => {
      const bn = [68, 54, 47, 39, 35, 32, 28, 24, 22, 18][i];
      const tkm = [20, 18, 22, 25, 28, 24, 19, 30, 22, 26][i];
      return `<tr><td><div class="rank${i < 3 ? ' top3' : ''}">${i + 1}</div></td><td><strong>${b}</strong></td><td>${KHOA[i]}</td><td>${bn} BN</td><td>${tkm} phút</td></tr>`;
    }).join('');
    f.appendChild(div('', tableCard('3.1 &nbsp;Hiệu Suất Bác Sĩ', 'Số lượt BN đã khám và thời gian khám trung bình trong kỳ', ['#', 'Bác Sĩ', 'Khoa', 'Số BN Đã Khám', 'TG Khám TB'], rows, 'Xem tất cả')));
    return f;
  },
  // Tab 4 – Hiệu Suất Vận Hành
  'ngoaitru-3': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '4.1 &nbsp;KPI – Thời Gian Quy Trình Khám &nbsp;<span style="color:var(--amber);font-size:10px;">(X = 30 phút – cấu hình trong Cài Đặt)</span>'));
    f.appendChild(div('kpi-grid col3', kpiCard('TG Đăng Ký → BS TB', '24<span class="kpi-sub2"> phút</span>', 'trung bình toàn ngày', '', 'neutral', '#1d63c4', IC.clock) + kpiCard('Tỷ Lệ Đạt Chuẩn (≤30 phút)', '72.4<span class="kpi-sub2">%</span>', 'BN chờ ≤ X phút', '', 'neutral', '#15803d', IC.check) + kpiCard('Tỷ Lệ Quá Chuẩn (>30 phút)', '27.6<span class="kpi-sub2">%</span>', 'BN chờ > X phút', '', 'neutral', '#881c1c', IC.x)));
    f.appendChild(div('sec-label', '4.2 &nbsp;KPI – Thời Gian Cấp Toa'));
    f.appendChild(div('kpi-grid col2', kpiCard('TG Thanh Toán → Nhận Thuốc TB', '18<span class="kpi-sub2"> phút</span>', 'từ thu tiền đến phát thuốc tại nhà thuốc', '', 'neutral', '#c0552f', IC.clock) + kpiCard('Tỷ Lệ Phát Thuốc Đúng Hạn', '84.2<span class="kpi-sub2">%</span>', 'nhận thuốc trong vòng 20 phút', '', 'neutral', '#15803d', IC.check)));
    const r = div('', '');
    r.innerHTML = chartCard('Phân Bố Thời Gian Chờ Khám', 'Số BN theo nhóm thời gian chờ (phút)', 'barWaitDist', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#15803d;"></div>Đạt chuẩn</div><div class="li"><div class="ld" style="background:#881c1c;"></div>Quá chuẩn</div></div>`);
    f.appendChild(r);
    return f;
  },
  // Tab 5 – Doanh Thu NT
  'ngoaitru-4': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('kpi-grid col3', kpiCard('Tổng Doanh Thu NT', '2.18<span class="kpi-sub2"> tỷ</span>', 'tháng 01/2025', '15.2%', 'up', '#15803d', IC.dollar) + kpiCard('DT TB / Lượt Khám', '650<span class="kpi-sub2"> nghìn</span>', 'VNĐ/lượt', '', 'neutral', '#1d63c4', IC.dollar) + kpiCard('Số Hóa Đơn', '3,352', 'hóa đơn đã phát sinh', '', 'neutral', '#c0552f', IC.activity)));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('5.2 &nbsp;Doanh Thu Theo Phòng Khám', 'Tổng DT theo từng phòng khám trong kỳ', 'barDTPhong', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#1d63c4;"></div>Doanh thu (triệu VND)</div></div>`) + chartCard('5.4 &nbsp;Doanh Thu Theo Đối Tượng', 'Tỷ trọng DT theo hình thức thanh toán', 'donutDTNT', `<div class="legend" style="margin-top:10px;flex-direction:column;gap:5px;">${[['#1d63c4', 'BHYT', '49.5%'], ['#c0552f', 'Dịch Vụ', '41.2%'], ['#15803d', 'BHTN', '6.8%'], ['#a4a4a0', 'Khác', '2.5%']].map(([c, n, p]) => `<div style="display:flex;justify-content:space-between;font-size:11.5px;"><div class="li"><div class="ld" style="background:${c};width:10px;height:10px;border-radius:3px;"></div>${n}</div><strong>${p}</strong></div>`).join('')}</div>`);
    f.appendChild(r);
    const r2 = div('', '');
    r2.innerHTML = chartCard('5.3 &nbsp;Doanh Thu Theo Bác Sĩ', 'Top 10 bác sĩ có doanh thu cao nhất trong kỳ', 'barDTBS', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#c0552f;"></div>Doanh thu (triệu VND)</div></div>`, 'Xem tất cả');
    f.appendChild(r2);
    const r3 = div('', '');
    r3.innerHTML = chartCard('5.5 &nbsp;Doanh Thu Theo Nhóm Dịch Vụ', 'Phân tích cơ cấu nguồn thu theo loại dịch vụ', 'barDTNhomDV', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#15803d;"></div>Doanh thu (triệu VND)</div></div>`);
    f.appendChild(r3);
    return f;
  },
  // Tab 6 – Cận Lâm Sàng NT
  'ngoaitru-5': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '6.1 &nbsp;KPI – Chỉ Định & TAT'));
    f.appendChild(div('kpi-grid col4', kpiCard('Tổng Chỉ Định XN', '1,248', 'xét nghiệm', '5.2%', 'up', '#1d63c4', IC.activity) + kpiCard('Tổng Chỉ Định CĐHA', '387', 'chẩn đoán hình ảnh', '3.8%', 'up', '#c0552f', IC.activity) + kpiCard('TAT TB Xét Nghiệm', '42<span class="kpi-sub2"> phút</span>', 'từ chỉ định → có kết quả', '', 'neutral', '#15803d', IC.clock) + kpiCard('TAT TB CĐHA', '68<span class="kpi-sub2"> phút</span>', 'từ chỉ định → có kết quả', '', 'neutral', '#b45309', IC.clock)));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('6.2 &nbsp;Xét Nghiệm Theo Nhóm', 'Số lượt chỉ định theo loại xét nghiệm', 'barXNNhom', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#1d63c4;"></div>Số lượt</div></div>`, 'Xem tất cả') + chartCard('6.3 &nbsp;CĐHA Theo Nhóm', 'Số lượt chỉ định theo loại CĐHA', 'barCDHANhom', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#c0552f;"></div>Số lượt</div></div>`, 'Xem tất cả');
    f.appendChild(r);
    return f;
  },
  // Tab 7 – Dược NT
  'ngoaitru-6': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '7.1 &nbsp;KPI – Thuốc Xuất / Phát'));
    f.appendChild(div('kpi-grid col2', kpiCard('Thuốc Xuất Bán (Dịch Vụ)', '12,480<span class="kpi-sub2"> đv</span>', 'số lượng xuất bán thu phí DV', '8.4%', 'up', '#1d63c4', IC.pill) + kpiCard('Thuốc Phát BHYT', '28,350<span class="kpi-sub2"> đv</span>', 'số lượng cấp phát theo chế độ BHYT', '3.2%', 'up', '#15803d', IC.pill)));
    f.appendChild(div('sec-label', '7.2 &nbsp;Tỷ Lệ Xuất Giữa Các Kho'));
    const r = div('', '');
    r.innerHTML = chartCard('Phân Bố Xuất Kho Theo Kho', 'Số lượng và tỷ lệ thuốc xuất từng kho trong kỳ', 'barKhoXuat', `<div class="legend" style="margin-top:8px;">${[['#1d63c4', 'Xuất bán DV'], ['#15803d', 'Phát BHYT']].map(([c, n]) => `<div class="li"><div class="ld" style="background:${c};"></div>${n}</div>`).join('')}</div>`);
    f.appendChild(r);
    return f;
  },
  // ══════════ NỘI TRÚ ══════════

  // Tab 4 – Phẫu Thuật
  'noitru-3': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('banner', `${IC.warning}<div><strong>Module Phẫu Thuật – Chưa Có Dữ Liệu ❓</strong>Chức năng này phụ thuộc bảng phẫu thuật chưa xác định tên. Giao diện được thiết kế sẵn với dữ liệu mẫu. DEV sẽ swap data source khi module sẵn sàng.</div>`));
    f.appendChild(div('kpi-grid col4', kpiCard('Tổng Ca Mổ', '12', 'ca hôm nay', '', 'neutral', '#403f3a', IC.activity) + kpiCard('Ca Cấp Cứu', '4', '33.3% tổng ca mổ', '', 'neutral', '#881c1c', IC.activity) + kpiCard('Ca Chương Trình', '8', '66.7% tổng ca mổ', '', 'neutral', '#15803d', IC.check) + kpiCard('Đã Hoàn Thành', '5', '5/12 ca trong ngày', '', 'neutral', '#1d63c4', IC.check)));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('Phân Loại Ca Mổ', 'Cấp cứu vs Chương trình trong kỳ', 'donutMo', `<div class="legend" style="margin-top:10px;flex-direction:column;gap:5px;">${[['#881c1c', 'Ca Cấp Cứu', '33%'], ['#15803d', 'Ca Chương Trình', '67%']].map(([c, n, p]) => `<div style="display:flex;justify-content:space-between;font-size:11.5px;"><div class="li"><div class="ld" style="background:${c};width:10px;height:10px;border-radius:3px;"></div>${n}</div><strong>${p}</strong></div>`).join('')}</div>`) + chartCard('Xu Hướng Ca Mổ 30 Ngày', 'Tổng ca mổ theo ngày trong kỳ', 'lineMo', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#403f3a;"></div>Tổng ca mổ</div><div class="li"><div class="ld" style="background:#881c1c;"></div>Cấp cứu</div></div>`);
    f.appendChild(r);
    return f;
  },
  // Tab 5 – Doanh Thu Nội Trú
  'noitru-4': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('kpi-grid col2', kpiCard('Tổng Doanh Thu Nội Trú', '2.08<span class="kpi-sub2"> tỷ</span>', 'tháng 01/2025', '12.4%', 'up', '#15803d', IC.dollar) + kpiCard('Chi Phí TB / BN Xuất Viện', '3.85<span class="kpi-sub2"> triệu</span>', 'VNĐ/BN ra viện', '', 'neutral', '#1d63c4', IC.dollar)));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('5.2 &nbsp;Doanh Thu Theo Khoa', 'Tổng DT nội trú từng khoa trong kỳ', 'barDTKhoaNT', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#15803d;"></div>Doanh thu (triệu VND)</div></div>`) + chartCard('5.3 &nbsp;Cơ Cấu Chi Phí Điều Trị', 'Tỷ trọng nhóm chi phí nội trú', 'donutCpNT', `<div class="legend" style="margin-top:10px;flex-direction:column;gap:5px;">${[['#1d63c4', 'Thuốc', '38%'], ['#c0552f', 'CLS (XN+CĐHA)', '28%'], ['#15803d', 'Giường/Phòng', '18%'], ['#b45309', 'Phẫu Thuật', '10%'], ['#a4a4a0', 'Vật Tư & Khác', '6%']].map(([c, n, p]) => `<div style="display:flex;justify-content:space-between;font-size:11.5px;"><div class="li"><div class="ld" style="background:${c};width:10px;height:10px;border-radius:3px;"></div>${n}</div><strong>${p}</strong></div>`).join('')}</div>`);
    f.appendChild(r);
    return f;
  },
  // Tab 6 – Dược Nội Trú
  'noitru-5': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '6.1 &nbsp;KPI – Sử Dụng Thuốc'));
    f.appendChild(div('kpi-grid col3', kpiCard('CP Thuốc TB / BN', '1.24<span class="kpi-sub2"> triệu</span>', 'VNĐ/BN nội trú', '', 'neutral', '#1d63c4', IC.pill) + kpiCard('Tỷ Lệ Sử Dụng Kháng Sinh', '58.3<span class="kpi-sub2">%</span>', 'BN có đơn KS / tổng BN', '', 'neutral', '#b45309', IC.pill) + kpiCard('Tỷ Lệ Bỏ Qua Cảnh Báo TT', '12.4<span class="kpi-sub2">%</span>', 'đơn bỏ qua cảnh báo tương tác', '', 'neutral', '#881c1c', IC.warning.replace('stroke="#92400e"', 'stroke="#881c1c"').replace('width="18" height="18"', '').replace('viewBox', 'width="13" height="13" viewBox'))));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('6.2 &nbsp;Chi Phí Thuốc Theo Khoa', 'Tổng chi phí thuốc từng khoa trong kỳ', 'barCpThuocKhoa', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#1d63c4;"></div>Chi phí (triệu VND)</div></div>`) + chartCard('6.3 &nbsp;CP Thuốc Theo Nhóm Bệnh (ICD)', 'Top 10 nhóm bệnh tiêu thụ chi phí thuốc cao nhất', 'barCpThuocICD', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#c0552f;"></div>Chi phí (triệu VND)</div></div>`, 'Xem tất cả');
    f.appendChild(r);
    return f;
  },
  // Tab 7 – CLS Nội Trú
  'noitru-6': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '7.1 &nbsp;KPI – Chỉ Định CLS'));
    f.appendChild(div('kpi-grid col3', kpiCard('Tổng Chỉ Định XN', '3,842', 'xét nghiệm trong kỳ', '8.2%', 'up', '#1d63c4', IC.activity) + kpiCard('Tổng Chỉ Định CĐHA', '1,205', 'chẩn đoán hình ảnh', '5.4%', 'up', '#c0552f', IC.activity) + kpiCard('CP CLS TB / BN', '485<span class="kpi-sub2"> nghìn</span>', 'VNĐ/BN nội trú', '', 'neutral', '#15803d', IC.dollar)));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('Xét Nghiệm Theo Nhóm', 'Phân tích XN theo loại – nội trú', 'barXNNT', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#1d63c4;"></div>Số lượt</div></div>`) + chartCard('CĐHA Theo Nhóm', 'Phân tích CĐHA theo loại – nội trú', 'barCDHANT', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#c0552f;"></div>Số lượt</div></div>`);
    f.appendChild(r);
    return f;
  },
  // ══════════ TÀI CHÍNH ══════════

  // Tab 3 – Nhóm Dịch Vụ
  'taichinh-2': () => {
    const f = document.createDocumentFragment();
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('3.1 &nbsp;Doanh Thu Theo Nhóm Dịch Vụ', 'Phân tích đóng góp của từng loại dịch vụ y tế', 'barDTNhomTC', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#15803d;"></div>Doanh thu (triệu VND)</div></div>`);
    r.innerHTML += tableCard('3.2 &nbsp;Top 10 Dịch Vụ DT Cao Nhất', 'Dịch vụ đóng góp doanh thu lớn nhất trong kỳ', ['Tên Dịch Vụ', 'Nhóm DV', 'Doanh Thu', 'Số Lượt', 'Trạng Thái'], [['Chụp CT Scanner', 'CĐHA', '285M', '342', 'green'], ['Xét Nghiệm Sinh Hóa', 'Xét Nghiệm', '218M', '2,450', 'green'], ['Khám Chuyên Khoa Tim', 'Khám', '195M', '890', 'green'], ['MRI Não', 'CĐHA', '182M', '215', 'green'], ['Siêu Âm Ổ Bụng', 'CĐHA', '156M', '1,205', 'green'], ['Nội Soi Dạ Dày', 'Thủ Thuật', '148M', '385', 'green'], ['XN Miễn Dịch', 'Xét Nghiệm', '132M', '892', 'green'], ['Điện Tim ECG', 'Thăm Dò CN', '98M', '1,654', 'blue'], ['XN Huyết Học', 'Xét Nghiệm', '87M', '3,120', 'blue'], ['Đo Loãng Xương', 'Thăm Dò CN', '76M', '428', 'blue']].map(([n, g, d, l, c]) => `<tr><td><strong>${n}</strong></td><td><span class="badge badge-navy">${g}</span></td><td style="font-weight:600;">${d}</td><td>${l}</td><td><span class="badge badge-${c === 'green' ? 'green' : 'blue'}">${c === 'green' ? 'Tốt' : 'Bình thường'}</span></td></tr>`).join(''), 'Xem tất cả');
    f.appendChild(r);
    return f;
  },
  // Tab 4 – Theo Khoa
  'taichinh-3': () => {
    const f = document.createDocumentFragment();
    const r = div('', '');
    r.innerHTML = chartCard('4.1 &nbsp;Doanh Thu Từng Khoa', 'Top 10 khoa theo DT + tỷ trọng – tháng 01/2025', 'barDTKhoa', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#1d63c4;"></div>Doanh thu (triệu VND)</div></div>`, 'Xem tất cả');
    f.appendChild(r);
    const dt = ['1,820M', '1,680M', '1,250M', '980M', '850M', '720M', '680M', '540M', '480M', '380M'];
    const pct = ['19.5%', '18.0%', '13.4%', '10.5%', '9.1%', '7.7%', '7.3%', '5.8%', '5.1%', '4.1%'];
    const trend = ['+18%', '+22%', '+15%', '+8%', '-3%', '+12%', '+5%', '+18%', '+2%', '-8%'];
    const tc_rows = KHOA.map((k, i) => {
      const up = trend[i].startsWith('+');
      return `<tr><td><div class="rank${i < 3 ? ' top3' : ''}">${i + 1}</div></td><td><strong>${k}</strong></td><td style="font-weight:600;">${dt[i]}</td><td>${pct[i]}</td><td><span class="badge ${up ? 'badge-green' : 'badge-red'}">${trend[i]}</span></td></tr>`;
    }).join('');
    f.appendChild(div('', tableCard('4.2–4.3 &nbsp;So Sánh & Tăng Trưởng Theo Khoa', 'DT kỳ này vs kỳ trước – sort theo DT giảm dần', ['#', 'Khoa', 'Doanh Thu', 'Tỷ Trọng', '% So Kỳ Trước'], tc_rows, 'Xem tất cả (32 khoa)')));
    return f;
  },
  // Tab 5 – Theo Bác Sĩ
  'taichinh-4': () => {
    const f = document.createDocumentFragment();
    const bs_dt = ['485M', '428M', '392M', '358M', '315M', '292M', '275M', '248M', '225M', '198M'];
    const bs_lk = [68, 54, 47, 39, 52, 35, 42, 28, 38, 31];
    const bs_rows = BS.map((b, i) => `<tr><td><div class="rank${i < 3 ? ' top3' : ''}">${i + 1}</div></td><td><strong>${b}</strong></td><td>${KHOA[i]}</td><td style="font-weight:600;">${bs_dt[i]}</td><td>${bs_lk[i]} lượt</td></tr>`).join('');
    f.appendChild(div('', tableCard('5.1 &nbsp;Doanh Thu Theo Bác Sĩ', 'Top 10 bác sĩ DT cao nhất – sort giảm dần', ['#', 'Bác Sĩ', 'Khoa', 'Doanh Thu', 'Số Lượt Khám'], bs_rows, 'Xem tất cả')));
    const r = div('', '');
    r.innerHTML = chartCard('5.2 &nbsp;Top 10 Bác Sĩ – Biểu Đồ', 'Doanh thu bác sĩ trong kỳ – thanh ngang', 'barDTBSTC', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#c0552f;"></div>Doanh thu (triệu VND)</div></div>`);
    f.appendChild(r);
    return f;
  },
  // ══════════ DƯỢC & VẬT TƯ ══════════

  // Tab 3 – Sử Dụng Thuốc
  'duoc-2': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '3.1 &nbsp;KPI – Chi Phí Thuốc Tổng Quan'));
    f.appendChild(div('kpi-grid col3', kpiCard('CP Thuốc Hôm Nay', '182<span class="kpi-sub2"> triệu</span>', 'xuất bán + cấp phát', '5.4%', 'up', '#1d63c4', IC.pill) + kpiCard('CP Thuốc TB / BN Nội Trú', '1.24<span class="kpi-sub2"> triệu</span>', 'VNĐ/BN điều trị nội trú', '', 'neutral', '#c0552f', IC.pill) + kpiCard('CP Thuốc TB / BN Ngoại Trú', '285<span class="kpi-sub2"> nghìn</span>', 'VNĐ/lượt khám ngoại trú', '', 'neutral', '#15803d', IC.pill)));
    f.appendChild(div('sec-label', '3.2 &nbsp;KPI – Tỷ Lệ Thuốc Đặc Thù'));
    f.appendChild(div('kpi-grid col2', `<div class="kpi-card" style="border-top-color:#b45309;">
        <div class="kpi-top"><div class="kpi-label">Tỷ Lệ Sử Dụng Kháng Sinh<br><small style="color:var(--muted2)">BN có đơn KS / tổng BN điều trị</small></div><div class="kpi-icon" style="background:var(--amber-bg)">${IC.pill}</div></div>
        <div class="kpi-val">58.3<span class="kpi-sub2">%</span></div>
        <div class="prog-wrap"><div class="prog-bar"><div class="prog-fill" style="width:58.3%;background:#b45309;"></div></div></div>
        <div class="kpi-bot" style="margin-top:6px;"><span class="kpi-sub">Mục tiêu: ≤ 50%</span></div>
      </div>` + `<div class="kpi-card" style="border-top-color:#881c1c;">
        <div class="kpi-top"><div class="kpi-label">Tỷ Lệ Sử Dụng Thuốc Đặc Trị<br><small style="color:var(--muted2)">BN có thuốc đặc trị / tổng BN điều trị</small></div><div class="kpi-icon" style="background:var(--red-bg)">${IC.pill}</div></div>
        <div class="kpi-val">22.7<span class="kpi-sub2">%</span></div>
        <div class="prog-wrap"><div class="prog-bar"><div class="prog-fill" style="width:22.7%;background:#881c1c;"></div></div></div>
        <div class="kpi-bot" style="margin-top:6px;"><span class="kpi-sub">Giám sát chặt theo phác đồ</span></div>
      </div>`));
    const r = div('row2 r55', '');
    r.innerHTML = tableCard('3.3 &nbsp;Top 10 Thuốc Sử Dụng Nhiều Nhất', 'Sort theo số lượng giảm dần trong kỳ', ['Tên Thuốc', 'Nhóm Dược Lý', 'Số Lượng', 'Giá Trị (VND)'], [['Amoxicillin 500mg', 'Kháng sinh', '12,450 viên', '24.9M'], ['Metformin 850mg', 'Nội tiết', '10,280 viên', '15.4M'], ['Omeprazole 40mg', 'Tiêu hóa', '9,850 viên', '19.7M'], ['Atorvastatin 20mg', 'Tim mạch', '8,620 viên', '25.9M'], ['Amlodipine 5mg', 'Tim mạch', '7,540 viên', '15.1M'], ['Ceftriaxone 1g', 'Kháng sinh', '2,850 lọ', '142.5M'], ['Paracetamol 500mg', 'Giảm đau', '15,200 viên', '7.6M'], ['Losartan 50mg', 'Tim mạch', '6,480 viên', '19.4M'], ['Prednisolone 5mg', 'Corticoid', '4,250 viên', '8.5M'], ['Vitamin C 500mg', 'Vitamin', '18,500 viên', '9.3M']].map(([n, g, q, v]) => `<tr><td><strong>${n}</strong></td><td><span class="badge badge-navy">${g}</span></td><td>${q}</td><td style="font-weight:600;">${v}</td></tr>`).join(''), 'Xem tất cả') + chartCard('3.4 &nbsp;Phân Tích Theo Nhóm Thuốc', 'Tỷ trọng chi phí theo nhóm dược lý', 'donutNhomThuoc', `<div class="legend" style="margin-top:10px;flex-direction:column;gap:5px;">${[['#881c1c', 'Kháng sinh', '28%'], ['#1d63c4', 'Tim mạch', '22%'], ['#15803d', 'Nội tiết', '18%'], ['#b45309', 'Ung thư', '12%'], ['#c0552f', 'Gây mê-HS', '8%'], ['#0e7490', 'GN-HT', '4%'], ['#a4a4a0', 'Khác', '8%']].map(([c, n, p]) => `<div style="display:flex;justify-content:space-between;font-size:11.5px;"><div class="li"><div class="ld" style="background:${c};width:10px;height:10px;border-radius:3px;"></div>${n}</div><strong>${p}</strong></div>`).join('')}</div>`);
    f.appendChild(r);
    return f;
  },
  // Tab 4 – Thuốc Theo Khoa
  'duoc-3': () => {
    const f = document.createDocumentFragment();
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('4.1 &nbsp;Chi Phí Thuốc Theo Khoa', 'Tổng chi phí thuốc từng khoa trong kỳ', 'barCpThuocKhoa2', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#1d63c4;"></div>Chi phí (triệu VND)</div></div>`) + chartCard('4.3 &nbsp;Khoa Dùng Kháng Sinh Cao Nhất', 'Top khoa theo CP kháng sinh – AMS Program', 'barKS', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#881c1c;"></div>Chi phí KS (triệu VND)</div></div>`);
    f.appendChild(r);
    const cpTT = ['45M', '38M', '32M', '28M', '52M', '35M', '48M', '22M', '25M', '18M'];
    const cpTr = ['38M', '32M', '28M', '24M', '45M', '30M', '42M', '18M', '22M', '20M'];
    const pct = ['+18%', '+19%', '+14%', '+17%', '+16%', '+17%', '+14%', '+22%', '+14%', '-10%'];
    const d3rows = KHOA.map((k, i) => {
      const up = pct[i].startsWith('+');
      return `<tr><td><strong>${k}</strong></td><td>${cpTT[i]}</td><td>${cpTr[i]}</td><td><span class="badge ${up ? 'badge-amber' : 'badge-green'}">${pct[i]}</span></td></tr>`;
    }).join('');
    f.appendChild(div('', tableCard('4.4 &nbsp;So Sánh CP Thuốc – Tháng Này vs Tháng Trước', 'Phát hiện khoa tăng chi phí thuốc đột biến', ['Khoa', 'Tháng Này', 'Tháng Trước', '% Thay Đổi'], d3rows)));
    return f;
  },
  // Tab 5 – Nhập Xuất Tồn
  'duoc-4': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '5.1 &nbsp;KPI – Tổng Quan Nhập Xuất'));
    f.appendChild(div('kpi-grid col5', `<div class="kpi-card" style="border-top-color:#15803d;"><div class="kpi-top"><div class="kpi-label">Tổng Nhập Kho</div><div class="kpi-icon" style="background:var(--green-bg);">${IC.pill}</div></div><div class="kpi-val">8.4<span class="kpi-sub2"> tỷ</span></div><div class="kpi-bot"><span class="kpi-sub">giá trị nhập trong kỳ</span></div></div>` + `<div class="kpi-card" style="border-top-color:#1d63c4;"><div class="kpi-top"><div class="kpi-label">Tổng Xuất Kho</div><div class="kpi-icon" style="background:var(--blue-bg);">${IC.activity}</div></div><div class="kpi-val">6.2<span class="kpi-sub2"> tỷ</span></div><div class="kpi-bot"><span class="kpi-sub">giá trị xuất trong kỳ</span></div></div>` + `<div class="kpi-card" style="border-top-color:#c0552f;"><div class="kpi-top"><div class="kpi-label">Xuất Nội Bộ</div><div class="kpi-icon" style="background:var(--purple-bg);">${IC.activity}</div></div><div class="kpi-val">0.8<span class="kpi-sub2"> tỷ</span></div><div class="kpi-bot"><span class="kpi-sub">chuyển giữa các kho</span></div></div>` + `<div class="kpi-card" style="border-top-color:#b45309;"><div class="kpi-top"><div class="kpi-label">Xuất Cho BN</div><div class="kpi-icon" style="background:var(--amber-bg);">${IC.user}</div></div><div class="kpi-val">5.4<span class="kpi-sub2"> tỷ</span></div><div class="kpi-bot"><span class="kpi-sub">cấp phát + bán cho BN</span></div></div>` + `<div class="kpi-card" style="border-top-color:#a4a4a0;"><div class="kpi-top"><div class="kpi-label">Hàng Trả Lại</div><div class="kpi-icon" style="background:rgba(148,163,184,0.12);">${IC.x}</div></div><div class="kpi-val">0.15<span class="kpi-sub2"> tỷ</span></div><div class="kpi-bot"><span class="kpi-sub">hoàn trả nhà cung cấp</span></div></div>`));
    const r = div('', '');
    r.innerHTML = chartCard('5.2 &nbsp;Nhập / Xuất Theo Kho', 'So sánh giá trị nhập và xuất từng kho trong kỳ', 'barNhapXuat', `<div class="legend" style="margin-top:8px;">${[['#15803d', 'Nhập kho'], ['#1d63c4', 'Xuất kho']].map(([c, n]) => `<div class="li"><div class="ld" style="background:${c};"></div>${n}</div>`).join('')}</div>`);
    f.appendChild(r);
    return f;
  },
  // Tab 6 – Vật Tư Tiêu Hao
  'duoc-5': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('kpi-grid col2', kpiCard('CP Vật Tư TB / Ca Mổ', '2.85<span class="kpi-sub2"> triệu</span>', 'VNĐ/ca phẫu thuật hoàn thành', '', 'neutral', '#c0552f', IC.activity) + kpiCard('Tổng Vật Tư Đã Xuất', '4,280<span class="kpi-sub2"> đv</span>', 'số lượng xuất trong kỳ', '', 'neutral', '#1d63c4', IC.activity)));
    const vt_rows = [['Kim tiêm các loại', 'Tiêu hao cơ bản', '18,450', '12.3M'], ['Gạc y tế các loại', 'Băng bó', '14,200', '8.5M'], ['Găng tay vô khuẩn', 'Bảo hộ', '12,800', '25.6M'], ['Dây truyền dịch', 'Tiêu hao cơ bản', '8,500', '17.0M'], ['Ống thông tiểu', 'Tiêu hao', '3,240', '16.2M'], ['Mặt nạ oxy', 'Hô hấp', '2,850', '14.3M'], ['Chỉ phẫu thuật', 'Phẫu thuật', '1,250', '62.5M'], ['Dao mổ', 'Phẫu thuật', '890', '44.5M'], ['Ống nội khí quản', 'Gây mê', '640', '32.0M'], ['Trocar nội soi', 'Nội soi', '285', '142.5M']].map(([n, g, q, v]) => `<tr><td><strong>${n}</strong></td><td><span class="badge badge-navy">${g}</span></td><td>${q}</td><td style="font-weight:600;">${v}</td></tr>`).join('');
    f.appendChild(div('', tableCard('6.1 &nbsp;Top 10 Vật Tư Tiêu Hao Nhiều Nhất', 'Sort theo số lượng sử dụng giảm dần trong kỳ', ['Tên Vật Tư', 'Nhóm', 'Số Lượng', 'Giá Trị'], vt_rows, 'Xem tất cả')));
    return f;
  },
  // Tab 7 – Thuốc Kiểm Soát Đặc Biệt
  'duoc-6': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('banner', `${IC.warning}<div><strong>Thuốc Kiểm Soát Đặc Biệt – Quản Lý Chặt Theo Quy Định Bộ Y Tế</strong>Dữ liệu này cần được kiểm soát và phân quyền truy cập đặc biệt.</div>`));
    f.appendChild(div('', tableCard('7.1 &nbsp;Tồn Kho Gây Nghiện – Hướng Thần', 'Số lượng tồn tại thời điểm hiện tại', ['Tên Thuốc', 'Phân Loại', 'Số Lô', 'Kho', 'Số Lượng Tồn'], [['Morphine 10mg/ml', 'GÂY NGHIỆN', 'L2024-12', 'Kho CC', '45 ống'], ['Fentanyl 0.1mg/2ml', 'GÂY NGHIỆN', 'L2024-11', 'Kho PT', '82 ống'], ['Midazolam 5mg/ml', 'HƯỚNG THẦN', 'L2024-12', 'Kho Gây Mê', '124 lọ'], ['Diazepam 10mg/2ml', 'HƯỚNG THẦN', 'L2024-10', 'Kho NT', '68 ống'], ['Phenobarbital 200mg', 'HƯỚNG THẦN', 'L2024-09', 'Kho TT', '150 viên']].map(([n, c, l, k, q]) => `<tr><td><strong>${n}</strong></td><td><span class="badge ${c === 'GÂY NGHIỆN' ? 'badge-red' : 'badge-amber'}">${c}</span></td><td><code style="font-size:10px;background:#F1F5F9;padding:1px 5px;border-radius:3px;">${l}</code></td><td>${k}</td><td style="font-weight:600;">${q}</td></tr>`).join(''), 'Xem tất cả')));
    const tbl2rows = [['Morphine 10mg/ml', 'Khoa Phẫu Thuật', '12 ống'], ['Fentanyl 0.1mg/2ml', 'Khoa Gây Mê', '28 ống'], ['Midazolam 5mg/ml', 'ICU', '35 lọ'], ['Diazepam 10mg/2ml', 'Khoa Thần Kinh', '15 ống'], ['Phenobarbital 200mg', 'Khoa Nội TH', '40 viên']].map(([n, k, q]) => `<tr><td><strong>${n}</strong></td><td>${k}</td><td>${q}</td></tr>`).join('');
    f.appendChild(div('', tableCard('7.2 &nbsp;Xuất Kho Gây Nghiện – Hướng Thần', 'Số lượng cấp phát trong kỳ', ['Tên Thuốc', 'Khoa Sử Dụng', 'Số Lượng Xuất'], tbl2rows, 'Xem tất cả')));
    return f;
  },
  // ══════════ CLS ══════════

  // Tab 0 – Tổng Quan CLS
  'cls-0': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '1.1 &nbsp;KPI – Tổng Quan Chỉ Định CLS Hôm Nay'));
    f.appendChild(div('kpi-grid col4', kpiCard('Tổng Chỉ Định CLS', '1,635', 'chỉ định phát sinh hôm nay', '8.4%', 'up', '#1d63c4', IC.activity) + kpiCard('BN Có Chỉ Định CLS', '892', 'bệnh nhân trong ngày', '5.2%', 'up', '#c0552f', IC.user) + kpiCard('Đã Thực Hiện', '1,482', 'chỉ định đã có kết quả', '', 'neutral', '#15803d', IC.check) + kpiCard('Đang Chờ Xử Lý', '153', 'chỉ định chưa có kết quả', '', 'neutral', '#b45309', IC.clock)));
    f.appendChild(div('sec-label', '1.2 &nbsp;KPI – Tỷ Lệ Hoàn Tất & Doanh Thu CLS'));
    f.appendChild(div('kpi-grid col2', `<div class="kpi-card" style="border-top-color:#15803d;"><div class="kpi-top"><div class="kpi-label">Tỷ Lệ Hoàn Tất Trong TAT Chuẩn<br><small style="color:var(--muted2)">Chỉ định xử lý xong trong X phút chuẩn (cấu hình)</small></div><div class="kpi-icon" style="background:rgba(21,128,61,0.12)">${IC.check}</div></div><div class="kpi-val">90.7<span class="kpi-sub2">%</span></div><div class="prog-wrap"><div class="prog-bar"><div class="prog-fill" style="width:90.7%;background:#15803d;"></div></div></div><div class="kpi-bot" style="margin-top:6px;"><span class="kpi-sub">1.482 / 1.635 hoàn tất &nbsp;·&nbsp; <span style="color:#b45309;font-weight:600;">153 đang chờ</span></span></div></div>` + kpiCard('Doanh Thu CLS Hôm Nay', '985<span class="kpi-sub2"> triệu</span>', 'thu từ toàn bộ dịch vụ cận lâm sàng', '12.3%', 'up', '#881c1c', IC.dollar)));
    const r = div('row2 r64', '');
    r.innerHTML = chartCard('1.3 &nbsp;Xu Hướng Chỉ Định CLS – 30 Ngày', 'Số lượng chỉ định XN, CĐHA và CLS khác theo ngày trong kỳ', 'lineClsOverview', `<div class="legend" style="margin-top:8px;">${[['#1d63c4', 'Xét nghiệm'], ['#c0552f', 'CĐHA'], ['#15803d', 'Nội soi & TDCN']].map(([c, n]) => `<div class="li"><div class="ld" style="background:${c};"></div>${n}</div>`).join('')}</div>`) + `<div class="chart-card"><div class="ch"><div><div class="ct">1.4 &nbsp;Cơ Cấu Chỉ Định CLS</div><div class="cs">Tỷ trọng theo loại dịch vụ – hôm nay</div></div></div><div class="chart-wrap"><canvas id="donutClsType"></canvas></div><div style="margin-top:12px;display:flex;flex-direction:column;gap:7px;">${[['#1d63c4', 'Xét Nghiệm', '1.248 lượt', '76.3%'], ['#c0552f', 'Chẩn Đoán Hình Ảnh', '312 lượt', '19.1%'], ['#15803d', 'Nội Soi', '48 lượt', '2.9%'], ['#b45309', 'Thăm Dò CN', '27 lượt', '1.7%']].map(([c, n, v, p]) => `<div style="display:flex;justify-content:space-between;align-items:center;font-size:11.5px;"><div class="li"><div class="ld" style="background:${c};width:10px;height:10px;border-radius:3px;"></div>${n}</div><div style="display:flex;gap:10px;"><span style="color:var(--text);font-weight:600;">${v}</span><span style="color:var(--muted);">${p}</span></div></div>`).join('')}</div></div>`;
    f.appendChild(r);
    return f;
  },
  // Tab 1 – Xét Nghiệm (LIS)
  'cls-1': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '2.1 &nbsp;KPI – Tổng Quan Xét Nghiệm'));
    f.appendChild(div('kpi-grid col4', kpiCard('Tổng Chỉ Định XN', '32,450', 'xét nghiệm trong kỳ', '5.2%', 'up', '#1d63c4', IC.activity) + kpiCard('BN Có Chỉ Định XN', '14,280', 'bệnh nhân trong kỳ', '3.8%', 'up', '#c0552f', IC.user) + kpiCard('TAT Trung Bình', '42<span class="kpi-sub2"> phút</span>', 'từ chỉ định → có kết quả', '', 'neutral', '#15803d', IC.clock) + kpiCard('Chỉ Định Quá TAT', '1,845', 'vượt thời gian chuẩn (5.7%)', '', 'neutral', '#881c1c', IC.x)));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('2.2 &nbsp;Số Lượng XN Theo Khoa', 'Số chỉ định xét nghiệm từng khoa lâm sàng trong kỳ', 'barXNKhoa2', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#1d63c4;"></div>Số lượng chỉ định</div></div>`, 'Xem tất cả') + chartCard('2.3 &nbsp;Thực Hiện Theo Máy', 'Số lượng mẫu xét nghiệm thực hiện trên từng máy phân tích', 'barXNMay2', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#c0552f;"></div>Số lượng mẫu</div></div>`);
    f.appendChild(r);
    const tatRows = [['Vi sinh (cấy & KSĐ)', '5,425', '180', '480', '18.5', 'red'], ['Hormone nội tiết', '4,385', '68', '120', '14.2', 'red'], ['Miễn dịch (Immunology)', '8,800', '58', '120', '12.3', 'amber'], ['Sinh hóa máu', '13,680', '42', '90', '8.4', 'amber'], ['Sinh hóa nước tiểu', '2,480', '38', '60', '7.8', 'amber'], ['Đông máu cơ bản', '5,980', '35', '60', '6.8', 'amber'], ['Huyết học toàn phần', '16,850', '28', '45', '5.2', 'green'], ['Tổng phân tích nước tiểu', '7,150', '22', '30', '3.2', 'green']].map(([t, sl, tatTb, tatMax, pct, c]) => `<tr><td><strong>${t}</strong></td><td>${sl}</td><td style="font-weight:600;color:${c === 'red' ? '#991b1b' : c === 'amber' ? '#92400e' : 'var(--text)'}">${tatTb} phút</td><td>${tatMax} phút</td><td><span class="badge ${c === 'green' ? 'badge-green' : c === 'amber' ? 'badge-amber' : 'badge-red'}">${pct}%</span></td></tr>`).join('');
    f.appendChild(div('', tableCard('2.4 &nbsp;TAT Theo Loại Xét Nghiệm', 'Thời gian trả kết quả trung bình – sort theo TAT giảm dần', ['Loại Xét Nghiệm', 'Số Lượng', 'TAT TB', 'TAT Tối Đa', '% Vượt Chuẩn'], tatRows, 'Xem tất cả')));
    return f;
  },
  // Tab 2 – Chẩn Đoán Hình Ảnh
  'cls-2': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '3.1 &nbsp;KPI – Tổng Quan Chẩn Đoán Hình Ảnh'));
    f.appendChild(div('kpi-grid col5', kpiCard('Tổng Ca CĐHA', '5,820', 'ca thực hiện trong kỳ', '6.8%', 'up', '#403f3a', IC.activity) + kpiCard('X-Quang (XQ)', '2,650', 'ca chụp X-Quang', '4.2%', 'up', '#1d63c4', IC.activity) + kpiCard('CT Scanner', '1,050', 'ca chụp cắt lớp', '8.5%', 'up', '#881c1c', IC.activity) + kpiCard('Siêu Âm (SA)', '1,720', 'ca siêu âm các loại', '5.1%', 'up', '#15803d', IC.activity) + kpiCard('MRI', '400', 'ca cộng hưởng từ', '12.4%', 'up', '#c0552f', IC.activity)));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('3.2 &nbsp;Tỷ Lệ Sử Dụng Máy CĐHA', '% thời gian hoạt động thực tế / tổng thời gian khả dụng &nbsp;·&nbsp; đỏ ≥ 80% (quá tải) · vàng ≥ 65%', 'barCDHAMay2', '') + `<div class="chart-card"><div class="ch"><div><div class="ct">3.3 &nbsp;Cơ Cấu Loại CĐHA</div><div class="cs">Tỷ trọng số ca theo phương thức chụp – kỳ hiện tại</div></div></div><div class="chart-wrap"><canvas id="donutCDHA2"></canvas></div><div style="margin-top:12px;display:flex;flex-direction:column;gap:7px;">${[['#1d63c4', 'X-Quang', '2.650 ca', '45.5%'], ['#15803d', 'Siêu Âm', '1.720 ca', '29.6%'], ['#881c1c', 'CT Scanner', '1.050 ca', '18.0%'], ['#c0552f', 'MRI', '400 ca', '6.9%']].map(([c, n, v, p]) => `<div style="display:flex;justify-content:space-between;align-items:center;font-size:11.5px;"><div class="li"><div class="ld" style="background:${c};width:10px;height:10px;border-radius:3px;"></div>${n}</div><div style="display:flex;gap:10px;"><span style="color:var(--text);font-weight:600;">${v}</span><span style="color:var(--muted);">${p}</span></div></div>`).join('')}</div></div>`;
    f.appendChild(r);
    return f;
  },
  // Tab 3 – Doanh Thu CLS
  'cls-3': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('sec-label', '4.4 &nbsp;KPI – Đóng Góp CLS Vào Tổng Doanh Thu Bệnh Viện'));
    f.appendChild(div('kpi-grid col3', `<div class="kpi-card" style="border-top-color:#881c1c;"><div class="kpi-top"><div class="kpi-label">Tỷ Lệ DT CLS / Tổng DT BV<br><small style="color:var(--muted2)">Đóng góp của mảng cận lâm sàng</small></div><div class="kpi-icon" style="background:rgba(136,28,28,0.10)">${IC.dollar}</div></div><div class="kpi-val">24.8<span class="kpi-sub2">%</span></div><div class="prog-wrap"><div class="prog-bar"><div class="prog-fill" style="width:24.8%;background:#881c1c;"></div></div></div><div class="kpi-bot" style="margin-top:6px;"><span class="kpi-sub">DT CLS: 1.06 tỷ &nbsp;|&nbsp; Tổng DT BV: 4.26 tỷ (tháng 01/2025)</span></div></div>` + kpiCard('Doanh Thu CLS Trong Kỳ', '1.06<span class="kpi-sub2"> tỷ</span>', 'tổng DT xét nghiệm + CĐHA + thủ thuật CLS', '15.2%', 'up', '#1d63c4', IC.dollar) + kpiCard('DT Trung Bình / Chỉ Định', '648<span class="kpi-sub2"> nghìn</span>', 'VNĐ trên mỗi chỉ định CLS', '', 'neutral', '#15803d', IC.dollar)));
    const r = div('row2 r55', '');
    r.innerHTML = chartCard('4.1 &nbsp;Doanh Thu Theo Loại Dịch Vụ CLS', 'Tổng DT từng nhóm dịch vụ CLS – sort giảm dần', 'barDTCLSLoai', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#881c1c;"></div>Doanh thu (triệu VND)</div></div>`) + chartCard('4.2 &nbsp;Doanh Thu Theo Máy CĐHA', 'Doanh thu phát sinh từ từng thiết bị – hiệu quả tài chính đầu tư', 'barDTCLSMay', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#c0552f;"></div>Doanh thu (triệu VND)</div></div>`);
    f.appendChild(r);
    const r2 = div('', '');
    r2.innerHTML = chartCard('4.3 &nbsp;Doanh Thu CLS Theo Khoa', 'Tổng DT CLS phát sinh từ chỉ định của từng khoa lâm sàng trong kỳ', 'barDTCLSKhoa', `<div class="legend" style="margin-top:8px;"><div class="li"><div class="ld" style="background:#1d63c4;"></div>Doanh thu (triệu VND)</div></div>`, 'Xem tất cả');
    f.appendChild(r2);
    return f;
  },
  // Tab 4 – Nội Soi (stub)
  'cls-4': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('banner', `${IC.warning}<div><strong>Module CLS – Nội Soi Chưa Sẵn Sàng</strong>Đang chờ tích hợp module nội soi. Giao diện sẽ bổ sung khi module LIS sẵn sàng.</div>`));
    return f;
  },
  // Tab 5 – Thăm Dò CN (stub)
  'cls-5': () => {
    const f = document.createDocumentFragment();
    f.appendChild(div('banner', `${IC.warning}<div><strong>Module CLS – Thăm Dò Chức Năng Chưa Sẵn Sàng</strong>Đang chờ tích hợp module thăm dò chức năng.</div>`));
    return f;
  }
});

// ── Mở rộng initCharts ──
const _baseInit = window.initCharts;
window.initCharts = function (key) {
  _baseInit(key);
  const EXT = {
    'ngoaitru-1': _initNT1,
    'ngoaitru-3': _initNT3,
    'ngoaitru-4': _initNT4,
    'ngoaitru-5': _initNT5,
    'ngoaitru-6': _initNT6,
    'noitru-3': _initNO3,
    'noitru-4': _initNO4,
    'noitru-5': _initNO5,
    'noitru-6': _initNO6,
    'taichinh-2': _initTC2,
    'taichinh-3': _initTC3,
    'taichinh-4': _initTC4,
    'duoc-2': _initD2,
    'duoc-3': _initD3,
    'duoc-4': _initD4,
    'duoc-5': _initD5,
    'cls-0': _initCLS0,
    'cls-1': _initCLS1,
    'cls-2': _initCLS2,
    'cls-3': _initCLS3
  };
  if (EXT[key]) EXT[key]();
};
const colors10 = ['#1d63c4', '#c0552f', '#15803d', '#b45309', '#881c1c', '#0e7490', '#8B5CF6', '#F97316', '#84CC16', '#EC4899'];
function _initNT1() {
  mkChart('barStackPK', 'bar', PKH.slice(0, 8), [{
    label: 'BHYT',
    data: [48, 40, 32, 28, 24, 20, 18, 25],
    backgroundColor: '#1d63c4',
    borderRadius: 2
  }, {
    label: 'DV',
    data: [22, 18, 14, 12, 10, 9, 7, 12],
    backgroundColor: '#c0552f',
    borderRadius: 2
  }, {
    label: 'BHTN',
    data: [8, 5, 5, 4, 3, 4, 2, 3],
    backgroundColor: '#15803d',
    borderRadius: 2
  }, {
    label: 'Miễn',
    data: [4, 4, 3, 4, 2, 2, 1, 2],
    backgroundColor: '#a4a4a0',
    borderRadius: 2
  }], {
    scales: {
      x: {
        stacked: true,
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        stacked: true,
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        padding: 10,
        cornerRadius: 8
      }
    }
  });
}
function _initNT3() {
  mkChart('barWaitDist', 'bar', ['0-10ph', '11-20ph', '21-30ph', '31-40ph', '41-50ph', '51-60ph', '>60ph'], [{
    data: [42, 98, 238, 105, 28, 8, 5],
    backgroundColor: ['#15803d', '#15803d', '#15803d', '#881c1c', '#881c1c', '#881c1c', '#881c1c'],
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initNT4() {
  mkChart('barDTPhong', 'bar', PKH.slice(0, 8), [{
    data: [285, 248, 195, 168, 142, 128, 98, 82],
    backgroundColor: colors10,
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
  mkChart('donutDTNT', 'doughnut', ['BHYT', 'Dịch Vụ', 'BHTN', 'Khác'], [{
    data: [49.5, 41.2, 6.8, 2.5],
    backgroundColor: ['#1d63c4', '#c0552f', '#15803d', '#a4a4a0'],
    borderWidth: 0,
    hoverOffset: 6
  }], {
    cutout: '72%',
    plugins: {
      legend: {
        display: false
      }
    }
  });
  mkChart('barDTBS', 'bar', BS, [{
    data: [485, 428, 392, 358, 315, 292, 275, 248, 225, 198],
    backgroundColor: '#c0552f',
    borderRadius: 4,
    barThickness: 16
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
  mkChart('barDTNhomDV', 'bar', ['Khám bệnh', 'Thuốc', 'Xét Nghiệm', 'CĐHA', 'Giường NT', 'Phẫu Thuật', 'Thủ Thuật', 'Vật Tư'], [{
    data: [520, 385, 320, 285, 210, 195, 145, 118],
    backgroundColor: colors10,
    borderRadius: 4
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initNT5() {
  mkChart('barXNNhom', 'bar', ['Huyết học', 'Sinh hóa', 'Vi sinh', 'Miễn dịch', 'Nước tiểu', 'Đông máu'], [{
    data: [425, 382, 148, 215, 195, 88],
    backgroundColor: '#1d63c4',
    borderRadius: 4,
    barThickness: 18
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      },
      y: {
        grid: {
          display: false
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
  mkChart('barCDHANhom', 'bar', ['Siêu âm', 'CT Scanner', 'X-Quang', 'MRI', 'Nội soi ống'], [{
    data: [185, 98, 72, 42, 28],
    backgroundColor: '#c0552f',
    borderRadius: 4,
    barThickness: 20
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      },
      y: {
        grid: {
          display: false
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initNT6() {
  mkChart('barKhoXuat', 'bar', ['Kho TT', 'Kho NT', 'Kho Ngoại Trú', 'Kho CC'], [{
    label: 'Xuất bán DV',
    data: [4200, 2800, 3500, 980],
    backgroundColor: '#1d63c4',
    borderRadius: 3
  }, {
    label: 'Phát BHYT',
    data: [8500, 6200, 7800, 2100],
    backgroundColor: '#15803d',
    borderRadius: 3
  }], {
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        padding: 10,
        cornerRadius: 8
      }
    }
  });
}
function _initNO3() {
  mkChart('donutMo', 'doughnut', ['Ca Cấp Cứu', 'Ca Chương Trình'], [{
    data: [33, 67],
    backgroundColor: ['#881c1c', '#15803d'],
    borderWidth: 0,
    hoverOffset: 6
  }], {
    cutout: '72%',
    plugins: {
      legend: {
        display: false
      }
    }
  });
  const d = [...Array(30)].map(() => Math.round(8 + Math.random() * 8));
  const e = [...Array(30)].map(() => Math.round(2 + Math.random() * 4));
  mkChart('lineMo', 'line', [...Array(30)].map((_, i) => i + 1), [{
    label: 'Tổng',
    data: d,
    borderColor: '#403f3a',
    backgroundColor: 'rgba(64,63,58,0.06)',
    borderWidth: 2,
    tension: .4,
    pointRadius: 0,
    fill: true
  }, {
    label: 'Cấp cứu',
    data: e,
    borderColor: '#881c1c',
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    tension: .4,
    pointRadius: 0
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          maxTicksLimit: 10,
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        min: 0
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        padding: 10,
        cornerRadius: 8
      }
    }
  });
}
function _initNO4() {
  mkChart('barDTKhoaNT', 'bar', KHOA, [{
    data: [520, 485, 320, 295, 248, 215, 195, 168, 142, 115],
    backgroundColor: colors10,
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
  mkChart('donutCpNT', 'doughnut', ['Thuốc', 'CLS', 'Giường', 'PT', 'Vật Tư'], [{
    data: [38, 28, 18, 10, 6],
    backgroundColor: ['#1d63c4', '#c0552f', '#15803d', '#b45309', '#a4a4a0'],
    borderWidth: 0,
    hoverOffset: 6
  }], {
    cutout: '72%',
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initNO5() {
  mkChart('barCpThuocKhoa', 'bar', KHOA, [{
    data: [285, 248, 195, 168, 142, 128, 98, 82, 65, 48],
    backgroundColor: '#1d63c4',
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
  mkChart('barCpThuocICD', 'bar', ['I21 NMCT', 'C50 Ung thư vú', 'N18 Suy thận', 'J18 Viêm phổi', 'I50 Suy tim', 'G35 Xơ cứng', 'E11 ĐTĐ', 'A41 NK huyết', 'J44 COPD', 'K92 Xuất huyết'], [{
    data: [182, 158, 145, 128, 115, 98, 88, 78, 68, 55],
    backgroundColor: '#c0552f',
    borderRadius: 4,
    barThickness: 16
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initNO6() {
  mkChart('barXNNT', 'bar', ['Huyết học', 'Sinh hóa', 'Vi sinh', 'Miễn dịch', 'Nước tiểu', 'Đông máu'], [{
    data: [1250, 985, 425, 585, 520, 278],
    backgroundColor: '#1d63c4',
    borderRadius: 4,
    barThickness: 20
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      },
      y: {
        grid: {
          display: false
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
  mkChart('barCDHANT', 'bar', ['Siêu âm', 'CT Scanner', 'X-Quang', 'MRI', 'Khác'], [{
    data: [485, 268, 195, 148, 65],
    backgroundColor: '#c0552f',
    borderRadius: 4,
    barThickness: 22
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      },
      y: {
        grid: {
          display: false
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initTC2() {
  mkChart('barDTNhomTC', 'bar', ['Khám bệnh', 'Thuốc', 'Xét Nghiệm', 'CĐHA', 'Giường NT', 'Phẫu Thuật', 'Thủ Thuật', 'Vật Tư'], [{
    data: [980, 865, 720, 635, 510, 485, 345, 278],
    backgroundColor: colors10,
    borderRadius: 4,
    barThickness: 18
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${c.raw}M VNĐ`
        }
      }
    }
  });
}
function _initTC3() {
  mkChart('barDTKhoa', 'bar', KHOA, [{
    data: [1820, 1680, 1250, 980, 850, 720, 680, 540, 480, 380],
    backgroundColor: colors10,
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${c.raw}M VNĐ`
        }
      }
    }
  });
}
function _initTC4() {
  mkChart('barDTBSTC', 'bar', BS, [{
    data: [485, 428, 392, 358, 315, 292, 275, 248, 225, 198],
    backgroundColor: '#c0552f',
    borderRadius: 4,
    barThickness: 16
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${c.raw}M VNĐ`
        }
      }
    }
  });
}
function _initD2() {
  mkChart('donutNhomThuoc', 'doughnut', ['Kháng sinh', 'Tim mạch', 'Nội tiết', 'Ung thư', 'GM-HS', 'GN-HT', 'Khác'], [{
    data: [28, 22, 18, 12, 8, 4, 8],
    backgroundColor: ['#881c1c', '#1d63c4', '#15803d', '#b45309', '#c0552f', '#0e7490', '#a4a4a0'],
    borderWidth: 0,
    hoverOffset: 6
  }], {
    cutout: '70%',
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initD3() {
  mkChart('barCpThuocKhoa2', 'bar', KHOA, [{
    data: [285, 248, 312, 185, 195, 145, 225, 98, 125, 75],
    backgroundColor: '#1d63c4',
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
  mkChart('barKS', 'bar', KHOA, [{
    data: [82, 48, 125, 28, 45, 35, 68, 18, 25, 12],
    backgroundColor: '#881c1c',
    borderRadius: 4,
    barThickness: 16
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initD4() {
  const khos = ['Kho TT', 'Kho NT', 'Kho Ngoại Trú', 'Kho CC', 'Kho PT'];
  mkChart('barNhapXuat', 'bar', khos, [{
    label: 'Nhập',
    data: [3.2, 2.1, 1.8, 0.65, 0.85],
    backgroundColor: '#15803d',
    borderRadius: 3
  }, {
    label: 'Xuất',
    data: [2.8, 1.9, 1.5, 0.58, 0.72],
    backgroundColor: '#1d63c4',
    borderRadius: 3
  }], {
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'tỷ'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${c.dataset.label}: ${c.raw} tỷ`
        }
      }
    }
  });
}
function _initD5() {/* no charts needed for tab 6 */}

// ── CLS chart inits ──
function _initCLS0() {
  const days = [...Array(30)].map((_, i) => {
    const d = new Date(2025, 0, 1 + i);
    return `${d.getDate()}/${d.getMonth() + 1}`;
  });
  const xn = days.map((_, i) => Math.round(38 + Math.sin(i * 0.4) * 8 + Math.random() * 6));
  const cdha = days.map((_, i) => Math.round(9 + Math.sin(i * 0.3) * 2 + Math.random() * 3));
  const ns = days.map(() => Math.round(1 + Math.random() * 3));
  mkChart('lineClsOverview', 'line', days, [{
    label: 'XN',
    data: xn,
    borderColor: '#1d63c4',
    backgroundColor: 'rgba(29,99,196,0.07)',
    borderWidth: 1.5,
    tension: .4,
    pointRadius: 0,
    fill: true
  }, {
    label: 'CĐHA',
    data: cdha,
    borderColor: '#c0552f',
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    tension: .4,
    pointRadius: 0
  }, {
    label: 'NS+TDCN',
    data: ns,
    borderColor: '#15803d',
    backgroundColor: 'transparent',
    borderWidth: 1,
    tension: .4,
    pointRadius: 0
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          maxTicksLimit: 8,
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        min: 0
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        padding: 10,
        cornerRadius: 8
      }
    }
  });
  mkChart('donutClsType', 'doughnut', ['Xét Nghiệm', 'CĐHA', 'Nội Soi', 'TDCN'], [{
    data: [76.3, 19.1, 2.9, 1.7],
    backgroundColor: ['#1d63c4', '#c0552f', '#15803d', '#b45309'],
    borderWidth: 0,
    hoverOffset: 6
  }], {
    cutout: '72%',
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initCLS1() {
  mkChart('barXNKhoa2', 'bar', KHOA, [{
    data: [4285, 3248, 2895, 2168, 1942, 1828, 3185, 1098, 1412, 1125],
    backgroundColor: colors10,
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${Number(c.raw).toLocaleString('vi-VN')} chỉ định`
        }
      }
    }
  });
  mkChart('barXNMay2', 'bar', ['Máy HH XS-1000i', 'Máy SH ADVIA 2400', 'Máy MD ARCHITECT i2000', 'Máy ĐM STA-R Max', 'Máy NT iQ200 SPRINT', 'Máy VS BD Phoenix 100'], [{
    data: [8502, 7208, 4852, 3201, 2804, 1885],
    backgroundColor: '#c0552f',
    borderRadius: 4,
    barThickness: 18
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${Number(c.raw).toLocaleString('vi-VN')} mẫu`
        }
      }
    }
  });
}
function _initCLS2() {
  const may = ['CT 64L Siemens SOMATOM', 'CT 128L Canon Aquilion', 'MRI 1.5T Philips Ingenia', 'XQ KTS GE Definium', 'SA Voluson E10', 'SA Doppler EPIQ 7'];
  const util = [85, 78, 72, 62, 68, 55];
  mkChart('barCDHAMay2', 'bar', may, [{
    data: util,
    backgroundColor: util.map(v => v >= 80 ? '#881c1c' : v >= 65 ? '#b45309' : '#15803d'),
    borderRadius: 5,
    barThickness: 20
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        min: 0,
        max: 100,
        ticks: {
          callback: v => v + '%',
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${c.raw}% sử dụng`
        }
      }
    }
  });
  mkChart('donutCDHA2', 'doughnut', ['X-Quang', 'Siêu Âm', 'CT Scanner', 'MRI'], [{
    data: [45.5, 29.6, 18.0, 6.9],
    backgroundColor: ['#1d63c4', '#15803d', '#881c1c', '#c0552f'],
    borderWidth: 0,
    hoverOffset: 6
  }], {
    cutout: '72%',
    plugins: {
      legend: {
        display: false
      }
    }
  });
}
function _initCLS3() {
  mkChart('barDTCLSLoai', 'bar', ['XN Sinh Hóa', 'CT Scanner', 'XN Miễn Dịch', 'Siêu Âm', 'XN Huyết Học', 'MRI', 'X-Quang', 'XN Vi Sinh', 'Nội Soi', 'Điện Tim ECG'], [{
    data: [485, 385, 320, 285, 215, 195, 145, 125, 98, 72],
    backgroundColor: ['#881c1c', '#881c1c', '#b45309', '#b45309', '#1d63c4', '#c0552f', '#1d63c4', '#1d63c4', '#15803d', '#15803d'],
    borderRadius: 4,
    barThickness: 18
  }], {
    indexAxis: 'y',
    scales: {
      x: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      },
      y: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${c.raw}M VNĐ`
        }
      }
    }
  });
  mkChart('barDTCLSMay', 'bar', ['CT 64L Siemens', 'MRI 1.5T Philips', 'CT 128L Canon', 'XQ KTS GE', 'SA Voluson E10', 'SA Doppler EPIQ'], [{
    data: [285, 195, 180, 145, 125, 98],
    backgroundColor: '#c0552f',
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${c.raw}M VNĐ`
        }
      }
    }
  });
  mkChart('barDTCLSKhoa', 'bar', KHOA, [{
    data: [428, 385, 320, 285, 245, 215, 195, 168, 145, 125],
    backgroundColor: colors10,
    borderRadius: 4
  }], {
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 9
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0,0,0,0.04)'
        },
        ticks: {
          callback: v => v + 'M'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        padding: 10,
        cornerRadius: 8,
        callbacks: {
          label: c => `${c.raw}M VNĐ`
        }
      }
    }
  });
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "panels-ext.js", error: String((e && e.message) || e) }); }

})();
